#include "Simplify.hpp"
#include "Traverse.hpp"
#include "Utilities.hpp"
#include "Hashing.hpp"
#include "CodeGenerator.hpp" //tmp
#include <unordered_map>

using namespace std;

namespace Sym {

Symbolic flattenAdditions(const Symbolic& expr) {
    
    if(expr.op() != ADD) return expr;
    
    vector<Symbolic> operands;
    
    preOrderTraverse(expr, [&](const Symbolic& x){
        if(x.op() != ADD) {
            if(x.ahash()) operands.push_back(x);
            return false;
        }
        
        return true;
    });
    
    auto ret = Symbolic(ADD, operands);
    if(ret.ahash() == .0) ret = .0;
    if(ret.numChilds() == 1) ret = Symbolic(ret[0]);
    
    return ret;
}

Symbolic flattenMultiplications(const Symbolic& expr) {
    
    if(expr.op() != MUL && expr.op() != MULC) return expr;
    
    vector<Symbolic> operands;
    
    preOrderTraverse(expr, [&](const Symbolic& x){
        if(x.op() != MUL && x.op() != MULC) {
            if(x.ahash() != 1.) operands.push_back(x);
            return false;
        }
        
        return true;
    });
    
    auto ret = Symbolic(MUL, operands);
    if(ret.numChilds() == 1.) ret = Symbolic(ret[0]);
    if(ret.numChilds() == 0) ret = 0.; // this can only work because we have flattend all multiplications
    if(ret.ahash() == 1.) ret = 1.;
    if(ret.ahash() == 0) ret = .0;
    
    return ret;
}

Symbolic eliminateSummands(const Symbolic& x) {
    
    if(x.op() != ADD) return x;
    
    return x;
}

Symbolic makeSymbolic(const unsigned char op, const vector<Symbolic>& operands) {
    if(operands.size() == 0) return .0; // have to be careful here. When op == MUL and this expression is a child of a multiplication it should be 1.
    if(operands.size() == 1) return operands.front();
    
    auto ret = Symbolic(op, operands);
    if(isSmallConstant(ret.ahash())) return (double)ret.ahash();
    else return ret;
}

Symbolic pullFactor(Symbolic x) {
    
    if(x.op() != ADD) return x;
    if(x.numChilds() == 1) return x[0];
    if(x.numChilds() == 0) return .0;
    
    
    cout << debugCode(x) << endl;
    
    vector<vector<Symbolic>> summands;
    summands.reserve(x.numChilds());
    
    for(const auto& c : x) {
        if(c.op() == MUL || c.op() == MULC) {
            vector<Symbolic> factors;
            auto fc = flattenMultiplications(c);
           
            if(fc.op() == MUL) {// 'c' could be a multiplication with a single operand
                for(auto& cc : flattenMultiplications(c))
                    factors.push_back(cc);
            } else factors.push_back(fc);
            
            summands.push_back(move(factors));
                
        } else summands.push_back({c});
    }
    
    
    // find factor(s) that are shared by as many summands as possible
    unordered_map<Symbolic, vector<int>, AlgebraicHashFunctor> factors;
  
    for(int i = 0; i < summands.size(); ++i) {
        for(auto& y : summands[i]) {
            factors[y].push_back(i);
        }
    }
    
    // choose largest set of summands sharing a factor
    auto maxSum = max_element(factors.begin(), factors.end(), [&](const auto& a, const auto& b) {
        return a.second.size() < b.second.size();})->second;

    bool atLeastTwo = false;
    for(auto i : maxSum) if(maxSum[0] != i) atLeastTwo = true;
    
    if(!atLeastTwo) return x; // no factor is present in more than one term
    
    // find factors appearing in all summands in 'maxSum'
    vector<Symbolic> pulledFactors;
    vector<pair<Symbolic, vector<int>>> rest;
    
    for(auto& fac : factors) {
        vector<int> diff;
        set_difference(fac.second.begin(), fac.second.end(),
                       maxSum.begin(), maxSum.end(), back_inserter(diff));
        
        if(diff.size() + maxSum.size() == fac.second.size()) {
            pulledFactors.push_back(fac.first);
        } else {
            rest.push_back(make_pair(fac.first, diff));
        }
    }
    
    // construct output 'pulledFactors' x 'maxSum' + rest
    vector<Symbolic> factored;
    for(int i : maxSum) {
        
        summands[i].erase(remove_if(summands[i].begin(), summands[i].end(), [&](const Symbolic& s) {
            for(auto& p : pulledFactors) if(p.ahash() == s.ahash()) return true;
            return false;
        }), summands[i].end());
        
        switch(summands[i].size()) {
            case 0: factored.push_back(Symbolic(1.));
                break;
            case 1: factored.push_back(summands[i][0]);
                break;
    
            default: factored.emplace_back(MUL, summands[i]);
        }
    }
    
    vector<vector<Symbolic>> summands2(summands.size());
    for(auto& r : rest) {
        for(int i : r.second) summands2[i].push_back(r.first);
    }
    
    vector<Symbolic> summands3;
    for(auto& sum : summands2) {
        if(sum.size() > 1) summands3.emplace_back(MUL, sum);
        else if(sum.size() == 1) summands3.push_back(sum[0]);
    }
    
    pulledFactors.push_back(pullFactor(Symbolic(ADD, factored)));
    
    if(pulledFactors.size() > 1) {
        summands3.push_back(Symbolic(MUL, pulledFactors));
    } else if(pulledFactors.size() == 1) summands3.push_back(pulledFactors[0]);
    
    return flattenAdditions(Symbolic(ADD, summands3));
}

Symbolic findNegative(const Symbolic& expr) {
    if(expr.op() == MULC && expr[0].constant() == -1) return Symbolic(NEG, expr[1]);
    return expr;
}

Symbolic simplifyExpression(const Symbolic& expr) {
    if(isSmallConstant(expr.ahash())) return (double)expr.ahash();
    
    auto x = flattenAdditions(expr);
    x = flattenMultiplications(x);
    x = pullFactor(x);
    // x = eliminateRoots
    // x = reduceFractions
    
    x = findNegative(x);
    return x;
}

Symbolic simplify(const Symbolic& expr) {
    
    vector<Symbolic> exprStack;
    vector<pair<Symbolic, unsigned int>> stack{make_pair(simplifyExpression(expr), 0)};
    
    while(!stack.empty()) {
        auto& x = stack.back();
        
        if(x.second == x.first.numChilds()) {
            if(x.second == 0) {
                exprStack.push_back(x.first);
            } else {
                Symbolic newExpr(x.first.op(), vector<Symbolic>(exprStack.end() - x.first.numChilds(), exprStack.end()));
                exprStack.erase(exprStack.end() - x.first.numChilds(), exprStack.end());
                exprStack.push_back(newExpr);
            }
            stack.pop_back();
        } else {
            auto xs = simplifyExpression(x.first[x.second]);
            x.second++;
            stack.push_back(make_pair(xs, 0));
        }
    }
    
    assert(exprStack.size() == 1);
    return exprStack.front();
}


}
