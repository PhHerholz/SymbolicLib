#include "ComputeKernel.hpp"
#include "Hashing.hpp"
#include "CodeGenerator.hpp"
#include <memory>
#include <map>
#include <utility>

using namespace std;

namespace {

Sym::hash_t hash(const vector<Sym::Symbolic>& x) {
    vector<Sym::hash_t> hashes;
    hashes.reserve(x.size());
    for(auto& xi : x) hashes.push_back(xi.ahash());
    return Sym::hash(hashes);
}

}

namespace Sym {

Kernel::Kernel(const std::vector<Symbolic>& expressions) {
    
    map<hash_t, Symbolic> xprMap;

    constexpr unsigned char LEAF_VAR = 2;
    constexpr unsigned char LEAF_OUTPUT_VAR = 3;
    constexpr unsigned char LEAF_CONST = 4;
    constexpr unsigned char REF = 5;
    
    struct StackData {
        vector<Symbolic> x;
        hash_t h;
        unsigned short childCounter = 0;
        unsigned char status = 0;
        
        bool visit() {
            return childCounter++ == x.front().numChilds();
        }
        
        unsigned short numChilds() const {
            return x.empty() ? 0 : x.front().numChilds();
        }
        
        OpType op() const {
            return x.empty() ? NOOP : x.front().op();
        }
        
        bool isValid() {
            
            for(auto& y : x) {
                if(y.op() != op()) return false;
                if(y.numChilds() != numChilds()) return false;
            }
            
            return true;
        }
        
        void init() {
            if(!x.empty()) {
                h = hash(x);
                if(x.front().op() == VAR) status = LEAF_VAR;
                else if(x.front().op() == CONST) status = LEAF_CONST;
            }
        }
        
        vector<array<int, 2>> getVariables() {
            if(op() == VAR) {
                const int n = x.size();
                vector<array<int, 2>> vals(n);
                bool allIdentical = true;
                
                for(int i = 0; i < n; ++i) {
                    vals[i] = x[i].variable();
                    if(allIdentical && vals[0] == vals[i]) allIdentical = false;
                }
                
                if(allIdentical) vals.erase(vals.begin() + 1, vals.end());
                return vals;
            }
            
            return {};
        }
        
        vector<double> getConstants() {
            if(op() == CONST) {
                const int n = x.size();
                vector<double> vals(n);
                bool allIdentical = true;
               
                for(int i = 0; i < n; ++i) {
                    vals[i] = x[i].constant();
                    if(allIdentical && vals[0] != vals[i]) allIdentical = false;
                }
                
                if(allIdentical) vals.erase(vals.begin() + 1, vals.end());
                return vals;
            }
            
            return {};
        }
        
        StackData& operator=(StackData&& b) {
            x.swap(b.x);
            b.x.clear();
            h = b.h;
            childCounter = b.childCounter;
            status = b.status;
            return *this;
        }
        
        StackData(StackData&& b) {
            *this = move(b);
        }
        
        StackData& operator=(const StackData& b) = default;
              
        StackData(const StackData& b) = default;
    
        StackData(const hash_t _h) : h(_h), status(REF) {}
        
        StackData(vector<Symbolic>&& data) : x(data) {
            init();
        }
       
        StackData(const vector<Symbolic>& data) : x(data) {
            init();
        }
        
        StackData(const vector<Symbolic>& data, const unsigned short numChild) {
            x.reserve(data.size());
            for(auto& d : data) x.push_back(d[numChild]);
            init();
        }
    };
    
    vector<StackData> stack{expressions};
    vector<Symbolic> tStack;
    map<hash_t, int> constMap;
    map<hash_t, int> varMap;
    
    map<hash_t, int> leafMap;
    
    
    while(!stack.empty()) {
        
        auto& curr = stack.back();
        assert(curr.isValid());
        
        if(curr.status == LEAF_VAR) {
            auto it = varMap.find(curr.h);
            if(it == varMap.end()) {
                tStack.emplace_back(variableTable.size(), -2);
                varMap[curr.h] = variableTable.size();
                variableTable.push_back(curr.getVariables());
            } else tStack.emplace_back(it->second, -2);
        } else if(curr.status == LEAF_CONST) {
            auto it = constMap.find(curr.h);
            if(it == constMap.end()) {
                it = constMap.insert(make_pair(curr.h, constantTable.size())).first;
                constantTable.push_back(curr.getConstants());
            }
             
            if(constantTable[it->second].size() == 1) tStack.emplace_back(constantTable[it->second].front());
            else tStack.emplace_back(it->second, -3);
            
        } else if(curr.status == REF) {
            tStack.push_back(xprMap[curr.h]);
        } else if(curr.visit()) {
            // all childs have been traversed
            Symbolic txpr(curr.op(), vector<Symbolic>(tStack.end() - curr.numChilds(), tStack.end()));
            tStack.erase(tStack.end() - curr.numChilds(), tStack.end());
            tStack.push_back(txpr);
            assert(xprMap.find(curr.h) == xprMap.end());
            xprMap[curr.h] = txpr;
        } else {
            StackData data(curr.x, curr.childCounter - 1);
            stack.push_back(move(data));
            auto h = stack.back().h;
            auto it = xprMap.find(h);
            
            if(it != xprMap.end()) {
                tStack.push_back(xprMap[curr.h]);
            } else {
                if(stack.back().op() == VAR) {
                    if(curr.op() == ASSIGN && curr.childCounter == 1) {
                        
                    } else {
                        
                    }
                } else if(stack.back().op() == CONST) {
                    auto values = stack.back().getConstants();
                    if(values.size() == 1) {
                        tStack.push_back(Symbolic(values.front()));
                    } else {
                        tStack.push_back(Symbolic(constantTable.size(), -3));
                        constantTable.push_back(move(values));
                    }
                }
                
                xprMap[h] = tStack.back();
            }
            
            if(s == REF) tStack.push_back(xprMap[h]);
            else if(s) {

                auto it = leafMap.find(h);
                
                if(it != leafMap.end()) {
                    tStack.emplace_back(it->second, -s);
                } else {
                    int newid;
                    if(s == LEAF_VAR) {
                        newid = variableTable.size();
                        variableTable.push_back(curr.getVariables());
                    } else if(s == LEAF_OUTPUT_VAR) {
                        newid = outputVariableTable.size();
                        outputVariableTable.push_back(curr.getVariables());
                    } else {
                        newid = constantTable.size();
                        constantTable.push_back(curr.getConstants());
                    }
                    
                    leafMap[h] = newid;
                }
                 
                if(it == varMap.end()) {
                    tStack.emplace_back(variableTable.size(), -2);
                    varMap[curr.h] = variableTable.size();
                    variableTable.push_back(curr.getVariables());
                } else tStack.emplace_back(it->second, -2);
            }
            // check if the new stack entry has been seen before, replace if possible.
     
           
            
            
            
            // handle leaves. There are three kinds: variables, output variables and constants
            
            
            
            continue; /* do not pop_back */
        }
        
        stack.pop_back();
    }
    
    assert(tStack.size() == 1);
    templateExpression = tStack.front();
}

Symbolic Kernel::getTemplateExpression() {
    return templateExpression;
}

}
